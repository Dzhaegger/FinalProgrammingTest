﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnmaze = New System.Windows.Forms.Button()
        Me.btncalc = New System.Windows.Forms.Button()
        Me.btnconversor = New System.Windows.Forms.Button()
        Me.btncalcimc = New System.Windows.Forms.Button()
        Me.btnamath1 = New System.Windows.Forms.Button()
        Me.btnmath2 = New System.Windows.Forms.Button()
        Me.pnltopp = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.btnminimize = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnltopp.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnmaze
        '
        Me.btnmaze.BackColor = System.Drawing.Color.Black
        Me.btnmaze.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmaze.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnmaze.Location = New System.Drawing.Point(343, 196)
        Me.btnmaze.Name = "btnmaze"
        Me.btnmaze.Size = New System.Drawing.Size(222, 64)
        Me.btnmaze.TabIndex = 7
        Me.btnmaze.Text = "MazeBank"
        Me.btnmaze.UseVisualStyleBackColor = False
        '
        'btncalc
        '
        Me.btncalc.BackColor = System.Drawing.Color.Black
        Me.btncalc.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncalc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btncalc.Location = New System.Drawing.Point(343, 90)
        Me.btncalc.Name = "btncalc"
        Me.btncalc.Size = New System.Drawing.Size(222, 64)
        Me.btncalc.TabIndex = 6
        Me.btncalc.Text = "Calculadora"
        Me.btncalc.UseVisualStyleBackColor = False
        '
        'btnconversor
        '
        Me.btnconversor.BackColor = System.Drawing.Color.Black
        Me.btnconversor.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconversor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnconversor.Location = New System.Drawing.Point(74, 196)
        Me.btnconversor.Name = "btnconversor"
        Me.btnconversor.Size = New System.Drawing.Size(222, 64)
        Me.btnconversor.TabIndex = 5
        Me.btnconversor.Text = "Conversor Temp"
        Me.btnconversor.UseVisualStyleBackColor = False
        '
        'btncalcimc
        '
        Me.btncalcimc.BackColor = System.Drawing.SystemColors.Desktop
        Me.btncalcimc.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.btncalcimc.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncalcimc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btncalcimc.Location = New System.Drawing.Point(74, 90)
        Me.btncalcimc.Name = "btncalcimc"
        Me.btncalcimc.Size = New System.Drawing.Size(222, 64)
        Me.btncalcimc.TabIndex = 4
        Me.btncalcimc.Text = "Calcular IMC"
        Me.btncalcimc.UseVisualStyleBackColor = False
        '
        'btnamath1
        '
        Me.btnamath1.BackColor = System.Drawing.Color.Black
        Me.btnamath1.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnamath1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnamath1.Location = New System.Drawing.Point(74, 300)
        Me.btnamath1.Name = "btnamath1"
        Me.btnamath1.Size = New System.Drawing.Size(222, 64)
        Me.btnamath1.TabIndex = 8
        Me.btnamath1.Text = "MathGame1"
        Me.btnamath1.UseVisualStyleBackColor = False
        '
        'btnmath2
        '
        Me.btnmath2.BackColor = System.Drawing.Color.Black
        Me.btnmath2.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmath2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnmath2.Location = New System.Drawing.Point(343, 300)
        Me.btnmath2.Name = "btnmath2"
        Me.btnmath2.Size = New System.Drawing.Size(222, 64)
        Me.btnmath2.TabIndex = 9
        Me.btnmath2.Text = "MathGame2"
        Me.btnmath2.UseVisualStyleBackColor = False
        '
        'pnltopp
        '
        Me.pnltopp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnltopp.BackColor = System.Drawing.Color.Black
        Me.pnltopp.Controls.Add(Me.Label1)
        Me.pnltopp.Controls.Add(Me.btnclose)
        Me.pnltopp.Controls.Add(Me.btnminimize)
        Me.pnltopp.Location = New System.Drawing.Point(-157, 0)
        Me.pnltopp.Name = "pnltopp"
        Me.pnltopp.Size = New System.Drawing.Size(800, 44)
        Me.pnltopp.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(166, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(249, 20)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Programming Test"
        '
        'btnclose
        '
        Me.btnclose.FlatAppearance.BorderSize = 0
        Me.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclose.Image = Global.FinalTest.My.Resources.Resources.CROSS_11
        Me.btnclose.Location = New System.Drawing.Point(749, 3)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(52, 41)
        Me.btnclose.TabIndex = 12
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'btnminimize
        '
        Me.btnminimize.FlatAppearance.BorderSize = 0
        Me.btnminimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnminimize.Image = Global.FinalTest.My.Resources.Resources._211863_minus_round_icon1
        Me.btnminimize.Location = New System.Drawing.Point(693, 3)
        Me.btnminimize.Name = "btnminimize"
        Me.btnminimize.Size = New System.Drawing.Size(52, 41)
        Me.btnminimize.TabIndex = 11
        Me.btnminimize.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Black
        Me.Label2.Font = New System.Drawing.Font("Mutter LVS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Green
        Me.Label2.Location = New System.Drawing.Point(242, 387)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(143, 11)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Jefferson S.C - 2023"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gray
        Me.BackgroundImage = Global.FinalTest.My.Resources.Resources.dark_texture_background_azhqarew9g05zkq6
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(643, 407)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.pnltopp)
        Me.Controls.Add(Me.btnmath2)
        Me.Controls.Add(Me.btnamath1)
        Me.Controls.Add(Me.btnmaze)
        Me.Controls.Add(Me.btncalc)
        Me.Controls.Add(Me.btnconversor)
        Me.Controls.Add(Me.btncalcimc)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.pnltopp.ResumeLayout(False)
        Me.pnltopp.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnmaze As Button
    Friend WithEvents btncalc As Button
    Friend WithEvents btnconversor As Button
    Friend WithEvents btncalcimc As Button
    Friend WithEvents btnamath1 As Button
    Friend WithEvents btnmath2 As Button
    Friend WithEvents pnltopp As Panel
    Friend WithEvents btnclose As Button
    Friend WithEvents btnminimize As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
