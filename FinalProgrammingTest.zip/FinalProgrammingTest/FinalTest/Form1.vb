﻿'EXAMEN FINAL PROGRAMACIÓN II
'JEFFERSON SALDAÑA CASTRO
'CUATRIMESTRE III UISIL 2023

Public Class Form1

    'Las Interfaces de Usuario fueron modificadas para tener una estética similar, exceptuando el Maze Bank.
    'Los botones del menú acceden a las diferentes tareas
    Private Sub btncalcimc_Click(sender As Object, e As EventArgs) Handles btncalcimc.Click
        CalculadoraIMC.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnmaze.Click
        MazeBankForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnconversor.Click
        Conversor.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btncalc.Click
        Calculadora.Show()
        Me.Hide()
    End Sub

    Private Sub btnamath1_Click(sender As Object, e As EventArgs) Handles btnamath1.Click
        MathGame1.Show()
        Me.Hide()
    End Sub

    Private Sub btnmath2_Click(sender As Object, e As EventArgs) Handles btnmath2.Click
        MathGame2.Show()
        Me.Hide()
    End Sub

    Private Sub btnminimize_Click(sender As Object, e As EventArgs) Handles btnminimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
End Class
