﻿Public Class CalculadoraIMC
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btncalc.Click
        ' Declarar variables para almacenar altura y peso.
        Dim altura As Double
        Dim peso As Double

        ' Intentar convertir el texto ingresado en los TextBox a números.
        If Double.TryParse(txtaltura.Text, altura) AndAlso Double.TryParse(txtpeso.Text, peso) Then
            If altura >= 0.5 AndAlso altura <= 2.5 AndAlso peso >= 10 AndAlso peso <= 500 Then


                ' Calcular el IMC (Índice de Masa Corporal).

                Dim imc As Double = peso / (altura * altura)

                ' Mostrar el resultado del IMC en el Label.
                lblresultado.Text = imc.ToString("F2") ' Formatea el resultado con dos decimales.

                ' Clasificar según el IMC calculado.
                If imc < 18.5 Then
                    lblcategoria.Text = "Bajo Peso"
                ElseIf imc >= 18.5 AndAlso imc < 25.0 Then
                    lblcategoria.Text = "Peso Normal"
                ElseIf imc >= 25.0 AndAlso imc < 30.0 Then
                    lblcategoria.Text = "Sobrepeso"
                ElseIf imc >= 30.0 AndAlso imc < 35.0 Then
                    lblcategoria.Text = "Obesidad de Grado I"
                ElseIf imc >= 35.0 AndAlso imc < 40.0 Then
                    lblcategoria.Text = "Obesidad de Grado II"
                Else
                    lblcategoria.Text = "Obesidad de Grado III"
                End If
            Else
                ' Si los valores están fuera de los rangos razonables, mostrar un mensaje de advertencia.
                MessageBox.Show("Por favor, ingrese valores válidos para altura y peso dentro de los rangos razonables.")
                ' Limpiar el texto del LabelResultado.
                lblresultado.Text = ""
            End If

        Else
            ' Si la conversión falla, mostrar un mensaje de error.
            MessageBox.Show("Por favor, ingresa valores válidos para altura y peso.")
            ' Limpiar el texto del lblresultado si ocurre un error.
            lblresultado.Text = ""
        End If
    End Sub
    'Minimizar el programa
    Private Sub btnminimizar_Click(sender As Object, e As EventArgs) Handles btnminimizar.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
    'Cerrar el programa
    Private Sub btncerrar_Click(sender As Object, e As EventArgs) Handles btncerrar.Click
        Me.Close()
        Form1.Show()
    End Sub

    Private Sub CalculadoraIMC_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
