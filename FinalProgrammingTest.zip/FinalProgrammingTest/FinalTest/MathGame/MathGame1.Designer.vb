﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MathGame1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblIntentos = New System.Windows.Forms.Label()
        Me.lblResultado = New System.Windows.Forms.Label()
        Me.txtnumero = New System.Windows.Forms.TextBox()
        Me.btnconfirmar = New System.Windows.Forms.Button()
        Me.btnreiniciar = New System.Windows.Forms.Button()
        Me.pnltop = New System.Windows.Forms.Panel()
        Me.lblmaintext = New System.Windows.Forms.Label()
        Me.btncerrar = New System.Windows.Forms.Button()
        Me.btnminizar = New System.Windows.Forms.Button()
        Me.pnltop.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblIntentos
        '
        Me.lblIntentos.AutoSize = True
        Me.lblIntentos.BackColor = System.Drawing.SystemColors.WindowText
        Me.lblIntentos.Font = New System.Drawing.Font("Mutter LVS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIntentos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblIntentos.Location = New System.Drawing.Point(185, 168)
        Me.lblIntentos.Name = "lblIntentos"
        Me.lblIntentos.Size = New System.Drawing.Size(109, 17)
        Me.lblIntentos.TabIndex = 11
        Me.lblIntentos.Text = "intentos"
        Me.lblIntentos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblResultado
        '
        Me.lblResultado.AutoSize = True
        Me.lblResultado.BackColor = System.Drawing.SystemColors.ControlText
        Me.lblResultado.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResultado.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblResultado.Location = New System.Drawing.Point(125, 207)
        Me.lblResultado.Name = "lblResultado"
        Me.lblResultado.Size = New System.Drawing.Size(147, 20)
        Me.lblResultado.TabIndex = 10
        Me.lblResultado.Text = "resultado"
        '
        'txtnumero
        '
        Me.txtnumero.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.txtnumero.Font = New System.Drawing.Font("Ebrima", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnumero.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtnumero.Location = New System.Drawing.Point(138, 108)
        Me.txtnumero.Name = "txtnumero"
        Me.txtnumero.Size = New System.Drawing.Size(357, 48)
        Me.txtnumero.TabIndex = 9
        '
        'btnconfirmar
        '
        Me.btnconfirmar.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnconfirmar.Font = New System.Drawing.Font("Mutter LVS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirmar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnconfirmar.Location = New System.Drawing.Point(337, 257)
        Me.btnconfirmar.Name = "btnconfirmar"
        Me.btnconfirmar.Size = New System.Drawing.Size(158, 43)
        Me.btnconfirmar.TabIndex = 8
        Me.btnconfirmar.Text = "Confirmar"
        Me.btnconfirmar.UseVisualStyleBackColor = False
        '
        'btnreiniciar
        '
        Me.btnreiniciar.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnreiniciar.Font = New System.Drawing.Font("Mutter LVS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreiniciar.ForeColor = System.Drawing.Color.Red
        Me.btnreiniciar.Location = New System.Drawing.Point(138, 257)
        Me.btnreiniciar.Name = "btnreiniciar"
        Me.btnreiniciar.Size = New System.Drawing.Size(164, 43)
        Me.btnreiniciar.TabIndex = 7
        Me.btnreiniciar.Text = "Reiniciar"
        Me.btnreiniciar.UseVisualStyleBackColor = False
        '
        'pnltop
        '
        Me.pnltop.BackColor = System.Drawing.Color.Black
        Me.pnltop.Controls.Add(Me.lblmaintext)
        Me.pnltop.Controls.Add(Me.btncerrar)
        Me.pnltop.Controls.Add(Me.btnminizar)
        Me.pnltop.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnltop.Location = New System.Drawing.Point(0, 0)
        Me.pnltop.Name = "pnltop"
        Me.pnltop.Size = New System.Drawing.Size(635, 41)
        Me.pnltop.TabIndex = 6
        '
        'lblmaintext
        '
        Me.lblmaintext.AutoSize = True
        Me.lblmaintext.BackColor = System.Drawing.Color.Black
        Me.lblmaintext.Font = New System.Drawing.Font("Mutter LVS", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmaintext.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblmaintext.Location = New System.Drawing.Point(6, 11)
        Me.lblmaintext.Name = "lblmaintext"
        Me.lblmaintext.Size = New System.Drawing.Size(263, 25)
        Me.lblmaintext.TabIndex = 6
        Me.lblmaintext.Text = "NumberGuesser"
        '
        'btncerrar
        '
        Me.btncerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btncerrar.FlatAppearance.BorderSize = 0
        Me.btncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncerrar.Image = Global.FinalTest.My.Resources.Resources.CROSS_11
        Me.btncerrar.Location = New System.Drawing.Point(583, 0)
        Me.btncerrar.Name = "btncerrar"
        Me.btncerrar.Size = New System.Drawing.Size(52, 41)
        Me.btncerrar.TabIndex = 7
        Me.btncerrar.UseVisualStyleBackColor = True
        '
        'btnminizar
        '
        Me.btnminizar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnminizar.BackgroundImage = Global.FinalTest.My.Resources.Resources._211863_minus_round_icon1
        Me.btnminizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnminizar.FlatAppearance.BorderSize = 0
        Me.btnminizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnminizar.Location = New System.Drawing.Point(530, 0)
        Me.btnminizar.Name = "btnminizar"
        Me.btnminizar.Size = New System.Drawing.Size(52, 41)
        Me.btnminizar.TabIndex = 6
        Me.btnminizar.UseVisualStyleBackColor = True
        '
        'MathGame1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.FinalTest.My.Resources.Resources.bfff
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(635, 382)
        Me.Controls.Add(Me.lblIntentos)
        Me.Controls.Add(Me.lblResultado)
        Me.Controls.Add(Me.txtnumero)
        Me.Controls.Add(Me.btnconfirmar)
        Me.Controls.Add(Me.btnreiniciar)
        Me.Controls.Add(Me.pnltop)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MathGame1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MathGame1"
        Me.pnltop.ResumeLayout(False)
        Me.pnltop.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblIntentos As Label
    Friend WithEvents lblResultado As Label
    Friend WithEvents txtnumero As TextBox
    Friend WithEvents btnconfirmar As Button
    Friend WithEvents btnreiniciar As Button
    Friend WithEvents pnltop As Panel
    Friend WithEvents lblmaintext As Label
    Friend WithEvents btncerrar As Button
    Friend WithEvents btnminizar As Button
End Class
