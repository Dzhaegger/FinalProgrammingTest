﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MathGame2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnltop = New System.Windows.Forms.Panel()
        Me.lblmaintxt = New System.Windows.Forms.Label()
        Me.btncerrar = New System.Windows.Forms.Button()
        Me.btnminimizar = New System.Windows.Forms.Button()
        Me.BtnVerificar = New System.Windows.Forms.Button()
        Me.txtRespuesta = New System.Windows.Forms.TextBox()
        Me.lblProblema = New System.Windows.Forms.Label()
        Me.pnltop.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnltop
        '
        Me.pnltop.BackColor = System.Drawing.Color.Black
        Me.pnltop.Controls.Add(Me.lblmaintxt)
        Me.pnltop.Controls.Add(Me.btncerrar)
        Me.pnltop.Controls.Add(Me.btnminimizar)
        Me.pnltop.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnltop.Location = New System.Drawing.Point(0, 0)
        Me.pnltop.Name = "pnltop"
        Me.pnltop.Size = New System.Drawing.Size(576, 45)
        Me.pnltop.TabIndex = 7
        '
        'lblmaintxt
        '
        Me.lblmaintxt.AutoSize = True
        Me.lblmaintxt.Font = New System.Drawing.Font("Mutter LVS", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmaintxt.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblmaintxt.Location = New System.Drawing.Point(5, 13)
        Me.lblmaintxt.Name = "lblmaintxt"
        Me.lblmaintxt.Size = New System.Drawing.Size(260, 25)
        Me.lblmaintxt.TabIndex = 4
        Me.lblmaintxt.Text = "ProblemSolver"
        '
        'btncerrar
        '
        Me.btncerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncerrar.BackgroundImage = Global.FinalTest.My.Resources.Resources.CROSS_11
        Me.btncerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btncerrar.FlatAppearance.BorderSize = 0
        Me.btncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncerrar.Location = New System.Drawing.Point(520, 0)
        Me.btncerrar.Name = "btncerrar"
        Me.btncerrar.Size = New System.Drawing.Size(56, 45)
        Me.btncerrar.TabIndex = 5
        Me.btncerrar.UseVisualStyleBackColor = True
        '
        'btnminimizar
        '
        Me.btnminimizar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnminimizar.BackgroundImage = Global.FinalTest.My.Resources.Resources._211863_minus_round_icon1
        Me.btnminimizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnminimizar.FlatAppearance.BorderSize = 0
        Me.btnminimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnminimizar.Location = New System.Drawing.Point(456, 0)
        Me.btnminimizar.Name = "btnminimizar"
        Me.btnminimizar.Size = New System.Drawing.Size(56, 45)
        Me.btnminimizar.TabIndex = 4
        Me.btnminimizar.UseVisualStyleBackColor = True
        '
        'BtnVerificar
        '
        Me.BtnVerificar.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BtnVerificar.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnVerificar.ForeColor = System.Drawing.Color.Red
        Me.BtnVerificar.Location = New System.Drawing.Point(180, 208)
        Me.BtnVerificar.Name = "BtnVerificar"
        Me.BtnVerificar.Size = New System.Drawing.Size(202, 56)
        Me.BtnVerificar.TabIndex = 6
        Me.BtnVerificar.Text = "Verificar"
        Me.BtnVerificar.UseVisualStyleBackColor = False
        '
        'txtRespuesta
        '
        Me.txtRespuesta.BackColor = System.Drawing.SystemColors.InfoText
        Me.txtRespuesta.Font = New System.Drawing.Font("Ebrima", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRespuesta.ForeColor = System.Drawing.Color.Red
        Me.txtRespuesta.Location = New System.Drawing.Point(85, 135)
        Me.txtRespuesta.Name = "txtRespuesta"
        Me.txtRespuesta.Size = New System.Drawing.Size(397, 42)
        Me.txtRespuesta.TabIndex = 5
        '
        'lblProblema
        '
        Me.lblProblema.AutoSize = True
        Me.lblProblema.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblProblema.Font = New System.Drawing.Font("Mutter LVS", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProblema.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblProblema.Location = New System.Drawing.Point(188, 90)
        Me.lblProblema.Name = "lblProblema"
        Me.lblProblema.Size = New System.Drawing.Size(166, 25)
        Me.lblProblema.TabIndex = 4
        Me.lblProblema.Text = "Problema"
        '
        'MathGame2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.FinalTest.My.Resources.Resources._360_F_282921499_9EVqjLXnI9Eejut5hv59I0SL1QkkeBye
        Me.ClientSize = New System.Drawing.Size(576, 305)
        Me.Controls.Add(Me.pnltop)
        Me.Controls.Add(Me.BtnVerificar)
        Me.Controls.Add(Me.txtRespuesta)
        Me.Controls.Add(Me.lblProblema)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MathGame2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MathGame2"
        Me.pnltop.ResumeLayout(False)
        Me.pnltop.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnltop As Panel
    Friend WithEvents lblmaintxt As Label
    Friend WithEvents btncerrar As Button
    Friend WithEvents btnminimizar As Button
    Friend WithEvents BtnVerificar As Button
    Friend WithEvents txtRespuesta As TextBox
    Friend WithEvents lblProblema As Label
End Class
