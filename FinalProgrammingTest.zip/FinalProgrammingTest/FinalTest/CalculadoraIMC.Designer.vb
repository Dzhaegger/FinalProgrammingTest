﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CalculadoraIMC
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CalculadoraIMC))
        Me.pnltopblue = New System.Windows.Forms.Panel()
        Me.lbltoptxt = New System.Windows.Forms.Label()
        Me.lblresultado = New System.Windows.Forms.Label()
        Me.lblcategoria = New System.Windows.Forms.Button()
        Me.btncalc = New System.Windows.Forms.Button()
        Me.txtaltura = New System.Windows.Forms.TextBox()
        Me.txtpeso = New System.Windows.Forms.TextBox()
        Me.lblimc = New System.Windows.Forms.Label()
        Me.lblaltura = New System.Windows.Forms.Label()
        Me.lblpeso = New System.Windows.Forms.Label()
        Me.btncerrar = New System.Windows.Forms.Button()
        Me.btnminimizar = New System.Windows.Forms.Button()
        Me.pnltopblue.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnltopblue
        '
        Me.pnltopblue.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnltopblue.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.pnltopblue.Controls.Add(Me.lbltoptxt)
        Me.pnltopblue.Controls.Add(Me.btncerrar)
        Me.pnltopblue.Controls.Add(Me.btnminimizar)
        Me.pnltopblue.Location = New System.Drawing.Point(-120, 0)
        Me.pnltopblue.Name = "pnltopblue"
        Me.pnltopblue.Size = New System.Drawing.Size(800, 44)
        Me.pnltopblue.TabIndex = 18
        '
        'lbltoptxt
        '
        Me.lbltoptxt.AutoSize = True
        Me.lbltoptxt.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltoptxt.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lbltoptxt.Location = New System.Drawing.Point(130, 13)
        Me.lbltoptxt.Name = "lbltoptxt"
        Me.lbltoptxt.Size = New System.Drawing.Size(230, 20)
        Me.lbltoptxt.TabIndex = 10
        Me.lbltoptxt.Text = "Calculadora IMC"
        '
        'lblresultado
        '
        Me.lblresultado.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblresultado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblresultado.Font = New System.Drawing.Font("Ebrima", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblresultado.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblresultado.Location = New System.Drawing.Point(170, 193)
        Me.lblresultado.Name = "lblresultado"
        Me.lblresultado.Size = New System.Drawing.Size(99, 25)
        Me.lblresultado.TabIndex = 17
        Me.lblresultado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblcategoria
        '
        Me.lblcategoria.BackColor = System.Drawing.Color.Black
        Me.lblcategoria.Font = New System.Drawing.Font("Mutter LVS", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcategoria.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblcategoria.Location = New System.Drawing.Point(337, 159)
        Me.lblcategoria.Name = "lblcategoria"
        Me.lblcategoria.Size = New System.Drawing.Size(156, 62)
        Me.lblcategoria.TabIndex = 16
        Me.lblcategoria.Text = "Clasificacion"
        Me.lblcategoria.UseVisualStyleBackColor = False
        '
        'btncalc
        '
        Me.btncalc.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btncalc.Font = New System.Drawing.Font("Mutter LVS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncalc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btncalc.Location = New System.Drawing.Point(337, 80)
        Me.btncalc.Name = "btncalc"
        Me.btncalc.Size = New System.Drawing.Size(156, 62)
        Me.btncalc.TabIndex = 15
        Me.btncalc.Text = "Calcular IMC"
        Me.btncalc.UseVisualStyleBackColor = False
        '
        'txtaltura
        '
        Me.txtaltura.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.txtaltura.Font = New System.Drawing.Font("Ebrima", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaltura.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtaltura.Location = New System.Drawing.Point(169, 131)
        Me.txtaltura.Name = "txtaltura"
        Me.txtaltura.Size = New System.Drawing.Size(100, 32)
        Me.txtaltura.TabIndex = 14
        Me.txtaltura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtpeso
        '
        Me.txtpeso.BackColor = System.Drawing.Color.Black
        Me.txtpeso.Font = New System.Drawing.Font("Ebrima", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpeso.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtpeso.Location = New System.Drawing.Point(169, 80)
        Me.txtpeso.Name = "txtpeso"
        Me.txtpeso.Size = New System.Drawing.Size(100, 32)
        Me.txtpeso.TabIndex = 13
        Me.txtpeso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblimc
        '
        Me.lblimc.AutoSize = True
        Me.lblimc.BackColor = System.Drawing.Color.Black
        Me.lblimc.Font = New System.Drawing.Font("Ebrima", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblimc.ForeColor = System.Drawing.Color.LawnGreen
        Me.lblimc.Location = New System.Drawing.Point(37, 193)
        Me.lblimc.Name = "lblimc"
        Me.lblimc.Size = New System.Drawing.Size(127, 25)
        Me.lblimc.TabIndex = 12
        Me.lblimc.Text = "IMC (Kg/m2)"
        '
        'lblaltura
        '
        Me.lblaltura.AutoSize = True
        Me.lblaltura.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblaltura.Font = New System.Drawing.Font("Ebrima", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblaltura.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblaltura.Location = New System.Drawing.Point(37, 131)
        Me.lblaltura.Name = "lblaltura"
        Me.lblaltura.Size = New System.Drawing.Size(103, 25)
        Me.lblaltura.TabIndex = 11
        Me.lblaltura.Text = "Altura (m)"
        '
        'lblpeso
        '
        Me.lblpeso.AutoSize = True
        Me.lblpeso.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblpeso.Font = New System.Drawing.Font("Ebrima", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpeso.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblpeso.Location = New System.Drawing.Point(37, 80)
        Me.lblpeso.Name = "lblpeso"
        Me.lblpeso.Size = New System.Drawing.Size(97, 25)
        Me.lblpeso.TabIndex = 10
        Me.lblpeso.Text = "Peso (Kg)"
        '
        'btncerrar
        '
        Me.btncerrar.BackgroundImage = CType(resources.GetObject("btncerrar.BackgroundImage"), System.Drawing.Image)
        Me.btncerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btncerrar.FlatAppearance.BorderSize = 0
        Me.btncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncerrar.Image = Global.FinalTest.My.Resources.Resources.CROSS_11
        Me.btncerrar.Location = New System.Drawing.Point(602, 0)
        Me.btncerrar.Name = "btncerrar"
        Me.btncerrar.Size = New System.Drawing.Size(52, 44)
        Me.btncerrar.TabIndex = 11
        Me.btncerrar.UseVisualStyleBackColor = True
        '
        'btnminimizar
        '
        Me.btnminimizar.BackgroundImage = CType(resources.GetObject("btnminimizar.BackgroundImage"), System.Drawing.Image)
        Me.btnminimizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnminimizar.FlatAppearance.BorderSize = 0
        Me.btnminimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnminimizar.Image = Global.FinalTest.My.Resources.Resources._211863_minus_round_icon1
        Me.btnminimizar.Location = New System.Drawing.Point(548, 0)
        Me.btnminimizar.Name = "btnminimizar"
        Me.btnminimizar.Size = New System.Drawing.Size(52, 44)
        Me.btnminimizar.TabIndex = 10
        Me.btnminimizar.UseVisualStyleBackColor = True
        '
        'CalculadoraIMC
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.FinalTest.My.Resources.Resources.dark_texture_background_azhqarew9g05zkq6
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(538, 264)
        Me.Controls.Add(Me.pnltopblue)
        Me.Controls.Add(Me.lblresultado)
        Me.Controls.Add(Me.lblcategoria)
        Me.Controls.Add(Me.btncalc)
        Me.Controls.Add(Me.txtaltura)
        Me.Controls.Add(Me.txtpeso)
        Me.Controls.Add(Me.lblimc)
        Me.Controls.Add(Me.lblaltura)
        Me.Controls.Add(Me.lblpeso)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "CalculadoraIMC"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CalculadoraIMC"
        Me.pnltopblue.ResumeLayout(False)
        Me.pnltopblue.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnltopblue As Panel
    Friend WithEvents lbltoptxt As Label
    Friend WithEvents btncerrar As Button
    Friend WithEvents btnminimizar As Button
    Friend WithEvents lblresultado As Label
    Friend WithEvents lblcategoria As Button
    Friend WithEvents btncalc As Button
    Friend WithEvents txtaltura As TextBox
    Friend WithEvents txtpeso As TextBox
    Friend WithEvents lblimc As Label
    Friend WithEvents lblaltura As Label
    Friend WithEvents lblpeso As Label
End Class
