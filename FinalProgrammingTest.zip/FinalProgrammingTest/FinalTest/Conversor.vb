﻿Public Class Conversor
    ' Este es el primer botón que convierte de Celsius a Fahrenheit.
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnfahrenheit.Click
        Dim c As Double ' Declaramos una variable para almacenar la temperatura en Celsius.

        ' Intentamos convertir el texto ingresado en el TextBox "Celsius" en un número decimal.
        If Double.TryParse(txtCelsius.Text, c) Then

            ' Si la conversión tiene éxito, calculamos y mostramos la temperatura en Fahrenheit.
            txtFahrenheit.Text = ((c * 9) / 5) + 32
        Else
            ' Si la conversión falla, mostramos un mensaje de advertencia.
            MessageBox.Show("Ingrese un valor numérico en Celsius")
        End If
    End Sub

    ' Este es el segundo botón que convierte de Fahrenheit a Celsius.
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btncelsius.Click
        Dim f As Double ' Declaramos una variable para almacenar la temperatura en Fahrenheit.

        ' Intentamos convertir el texto ingresado en el TextBox "Fahrenheit" en un número decimal.
        If Double.TryParse(txtFahrenheit.Text, f) Then

            ' Si la conversión es correcta, calculamos y mostramos la temperatura en Celsius.
            txtCelsius.Text = ((f - 32) * 5) / 9
        Else
            ' Si la conversión falla, mostramos un mensaje de advertencia.
            MessageBox.Show("Ingrese un valor numérico en Fahrenheit")
        End If
    End Sub

    ' Minimiza la ventana cuando se hace click en el botón "Minimizar".
    Private Sub btnminimizar_Click(sender As Object, e As EventArgs) Handles btnminimizar.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    ' Cierra la aplicación cuando se hace click en el botón "Cerrar".
    Private Sub btncerrar_Click(sender As Object, e As EventArgs) Handles btncerrar.Click
        Me.Close()
        Form1.Show()
    End Sub


    ' Simplemente un "Titulo". No hace nada en este código.
    Private Sub Titulo_Click(sender As Object, e As EventArgs) Handles lbltoptxt.Click
    End Sub

    Private Sub Conversor_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
