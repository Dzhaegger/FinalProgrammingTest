﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Conversor
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Conversor))
        Me.btncelsius = New System.Windows.Forms.Button()
        Me.pnltopgreen = New System.Windows.Forms.Panel()
        Me.lbltoptxt = New System.Windows.Forms.Label()
        Me.btncerrar = New System.Windows.Forms.Button()
        Me.btnminimizar = New System.Windows.Forms.Button()
        Me.btnfahrenheit = New System.Windows.Forms.Button()
        Me.txtFahrenheit = New System.Windows.Forms.TextBox()
        Me.txtCelsius = New System.Windows.Forms.TextBox()
        Me.lblfahrenheit = New System.Windows.Forms.Label()
        Me.lblcelsius = New System.Windows.Forms.Label()
        Me.pnltopgreen.SuspendLayout()
        Me.SuspendLayout()
        '
        'btncelsius
        '
        Me.btncelsius.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btncelsius.Font = New System.Drawing.Font("Mutter LVS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncelsius.ForeColor = System.Drawing.Color.Olive
        Me.btncelsius.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btncelsius.Location = New System.Drawing.Point(372, 205)
        Me.btncelsius.Name = "btncelsius"
        Me.btncelsius.Size = New System.Drawing.Size(166, 62)
        Me.btncelsius.TabIndex = 13
        Me.btncelsius.Text = "Celsius"
        Me.btncelsius.UseVisualStyleBackColor = False
        '
        'pnltopgreen
        '
        Me.pnltopgreen.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnltopgreen.BackColor = System.Drawing.Color.Black
        Me.pnltopgreen.Controls.Add(Me.lbltoptxt)
        Me.pnltopgreen.Controls.Add(Me.btncerrar)
        Me.pnltopgreen.Controls.Add(Me.btnminimizar)
        Me.pnltopgreen.Location = New System.Drawing.Point(0, 0)
        Me.pnltopgreen.Name = "pnltopgreen"
        Me.pnltopgreen.Size = New System.Drawing.Size(692, 55)
        Me.pnltopgreen.TabIndex = 12
        '
        'lbltoptxt
        '
        Me.lbltoptxt.AutoSize = True
        Me.lbltoptxt.Font = New System.Drawing.Font("Mutter LVS", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltoptxt.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lbltoptxt.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lbltoptxt.Location = New System.Drawing.Point(6, 20)
        Me.lbltoptxt.Name = "lbltoptxt"
        Me.lbltoptxt.Size = New System.Drawing.Size(375, 20)
        Me.lbltoptxt.TabIndex = 7
        Me.lbltoptxt.Text = "Conversor de Temperatura"
        '
        'btncerrar
        '
        Me.btncerrar.BackgroundImage = CType(resources.GetObject("btncerrar.BackgroundImage"), System.Drawing.Image)
        Me.btncerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btncerrar.FlatAppearance.BorderSize = 0
        Me.btncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncerrar.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btncerrar.Location = New System.Drawing.Point(623, 0)
        Me.btncerrar.Name = "btncerrar"
        Me.btncerrar.Size = New System.Drawing.Size(67, 55)
        Me.btncerrar.TabIndex = 8
        Me.btncerrar.UseVisualStyleBackColor = True
        '
        'btnminimizar
        '
        Me.btnminimizar.BackgroundImage = CType(resources.GetObject("btnminimizar.BackgroundImage"), System.Drawing.Image)
        Me.btnminimizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnminimizar.FlatAppearance.BorderSize = 0
        Me.btnminimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnminimizar.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnminimizar.Location = New System.Drawing.Point(560, 0)
        Me.btnminimizar.Name = "btnminimizar"
        Me.btnminimizar.Size = New System.Drawing.Size(67, 55)
        Me.btnminimizar.TabIndex = 7
        Me.btnminimizar.UseVisualStyleBackColor = True
        '
        'btnfahrenheit
        '
        Me.btnfahrenheit.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnfahrenheit.Font = New System.Drawing.Font("Mutter LVS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfahrenheit.ForeColor = System.Drawing.Color.Green
        Me.btnfahrenheit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnfahrenheit.Location = New System.Drawing.Point(178, 205)
        Me.btnfahrenheit.Name = "btnfahrenheit"
        Me.btnfahrenheit.Size = New System.Drawing.Size(166, 62)
        Me.btnfahrenheit.TabIndex = 11
        Me.btnfahrenheit.Text = "Fahrenheit"
        Me.btnfahrenheit.UseVisualStyleBackColor = False
        '
        'txtFahrenheit
        '
        Me.txtFahrenheit.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.txtFahrenheit.Font = New System.Drawing.Font("Ebrima", 14.25!, System.Drawing.FontStyle.Bold)
        Me.txtFahrenheit.ForeColor = System.Drawing.Color.Olive
        Me.txtFahrenheit.Location = New System.Drawing.Point(269, 142)
        Me.txtFahrenheit.Name = "txtFahrenheit"
        Me.txtFahrenheit.Size = New System.Drawing.Size(188, 32)
        Me.txtFahrenheit.TabIndex = 10
        Me.txtFahrenheit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCelsius
        '
        Me.txtCelsius.BackColor = System.Drawing.SystemColors.MenuText
        Me.txtCelsius.Font = New System.Drawing.Font("Ebrima", 14.25!, System.Drawing.FontStyle.Bold)
        Me.txtCelsius.ForeColor = System.Drawing.Color.Green
        Me.txtCelsius.Location = New System.Drawing.Point(269, 92)
        Me.txtCelsius.Name = "txtCelsius"
        Me.txtCelsius.Size = New System.Drawing.Size(188, 32)
        Me.txtCelsius.TabIndex = 9
        Me.txtCelsius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblfahrenheit
        '
        Me.lblfahrenheit.AutoSize = True
        Me.lblfahrenheit.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblfahrenheit.Font = New System.Drawing.Font("Mutter LVS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfahrenheit.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblfahrenheit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblfahrenheit.Location = New System.Drawing.Point(133, 149)
        Me.lblfahrenheit.Name = "lblfahrenheit"
        Me.lblfahrenheit.Size = New System.Drawing.Size(133, 17)
        Me.lblfahrenheit.TabIndex = 8
        Me.lblfahrenheit.Text = "Fahrenheit"
        '
        'lblcelsius
        '
        Me.lblcelsius.AutoSize = True
        Me.lblcelsius.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblcelsius.Font = New System.Drawing.Font("Mutter LVS", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcelsius.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblcelsius.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblcelsius.Location = New System.Drawing.Point(160, 99)
        Me.lblcelsius.Name = "lblcelsius"
        Me.lblcelsius.Size = New System.Drawing.Size(105, 17)
        Me.lblcelsius.TabIndex = 7
        Me.lblcelsius.Text = " Celsius"
        '
        'Conversor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.FinalTest.My.Resources.Resources.bfff
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(692, 316)
        Me.Controls.Add(Me.btncelsius)
        Me.Controls.Add(Me.pnltopgreen)
        Me.Controls.Add(Me.btnfahrenheit)
        Me.Controls.Add(Me.txtFahrenheit)
        Me.Controls.Add(Me.txtCelsius)
        Me.Controls.Add(Me.lblfahrenheit)
        Me.Controls.Add(Me.lblcelsius)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Conversor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Conversor"
        Me.pnltopgreen.ResumeLayout(False)
        Me.pnltopgreen.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btncelsius As Button
    Friend WithEvents pnltopgreen As Panel
    Friend WithEvents lbltoptxt As Label
    Friend WithEvents btncerrar As Button
    Friend WithEvents btnminimizar As Button
    Friend WithEvents btnfahrenheit As Button
    Friend WithEvents txtFahrenheit As TextBox
    Friend WithEvents txtCelsius As TextBox
    Friend WithEvents lblfahrenheit As Label
    Friend WithEvents lblcelsius As Label
End Class
